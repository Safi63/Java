// Fig. 20.9: StackTest.java
// Stack generic class test program.

public class StackTest 
{
	public static void main(String[] args) 
	{
		Fruit[] Fruits = new Fruit[4];	
		Fruits[0] = new Kino(3,5);
		Fruits[1] = new Malta(3,4); 
		Fruits[2] = new Kharboza(2,7);
		Fruits[3] = new Tarboz(13,2);
		Stack<Fruit> FruitStack = new Stack<>();
		
		// push elements of fruitElements onto fruitStack
		testPushFruit(FruitStack, Fruits); 
		testPopFruit(FruitStack); // pop from fruitStack
	} 
		
	// test push method with Fruit stack
	private static void testPushFruit(
	Stack<Fruit> stack, Fruit[] values)
	{
		System.out.printf("%nPushing elements onto fruitStack%n");
		
		// push elements to Stack
		for (Fruit value : values)
		{
			System.out.println(value);
			stack.push(value); // push onto fruitStack
		}
	}
	
	// test pop method with double stack
	private static void testPopFruit(Stack<Fruit> stack)
	{
		// pop elements from stack
		try
		{
			System.out.printf("%nPopping elements from fruitStack%n");
			Fruit popValue; // store element removed from stack
			
			// remove all elements from Stack
			while (true)
			{
				popValue =   stack.pop(); // pop from doubleStack
				System.out.println(popValue); 
			} 
		}
		catch(EmptyStackException emptyStackException)
		{
			System.err.println();
			emptyStackException.printStackTrace();
		} 
	}
} // end class StackTest